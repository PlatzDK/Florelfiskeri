# Florel Fiskeri

Dette repository indeholder kildekoden og indholdet til Florel Fiskeri,
et statisk website for udlejning af et sommerhus ved Karup Å.  Sitet er
bygget med den statiske site‑generator **Eleventy (11ty)**, der er valgt på
grund af sin enkelhed, fleksibilitet og høje performance【880433695797556†L80-L105】.

## Struktur

Indholdet er organiseret i `content/` mappen som Markdown‑filer opdelt efter
sprog (da, en, de).  Skabeloner findes i `content/_includes/`, og alle
statisk assets som billeder og CSS ligger under `assets/`.  Outputtet
genereres automatisk til `dist/` mappen ved hjælp af NPM scriptet `npm run build`.

## Byg og kør lokalt

1. Installer afhængigheder:

   ```sh
   npm install
   ```

2. Kør udviklingsserver:

   ```sh
   npm run dev
   ```

   Serveren kører som standard på http://localhost:8080, og ændringer i
   filerne genkompileres automatisk.

3. Byg til produktion:

   ```sh
   npm run build
   ```

## Udgivelse

Projektet er konfigureret til at blive udgivet på GitHub Pages via
GitHub Actions (se `.github/workflows/deploy.yml`). Alternativt kan
`netlify.toml` bruges til hosting på Netlify.  Udgivelsesprocessen er
automatiseret, så hver gang der pushes til `main` branchen, bygges og
deployes sitet automatisk.

## Dokumentation

Se `docs/AI_README_v1.md` for en detaljeret guide til AI‑assistenter om,
hvorfor denne arkitektur er valgt, og hvordan indhold opdateres og
vedligeholdes.  Den fil indeholder også retningslinjer for SEO, sprog og
versionering.
