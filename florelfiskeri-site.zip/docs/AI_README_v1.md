---
title: "AI Contribution Guide"
version: 1.0
last_updated: "2025-08-06"
---

# AI Contribution Guide (v1.0)

Denne fil beskriver arkitekturen og konfigurationsvalgene for **Florel Fiskeri**
projektet og forklarer, hvordan AI‑assistenter som ChatGPT kan hjælpe med
vedligeholdelse, opdateringer og optimering.  Formålet er at gøre det
gennemsigtigt for både mennesker og AI‑modeller at navigere i koden, forbedre
indhold og sikre høj performance.

## Valgt arkitektur

### Statisk site‑generator

Projektet er bygget med **Eleventy (11ty)**, en moderne statisk site‑generator.
Valget er truffet, fordi Eleventy giver **fuld kontrol over outputtet** og
inkluderer **ingen store runtime‑biblioteker**, hvilket resulterer i hurtige
loadtider【593521916954360†L168-L174】.  Eleventy er også kendt for sin
**simplicitet, fleksibilitet og hastighed**【880433695797556†L80-L105】.  Med
Eleventy kan man arbejde med flere skabelonsprog (Markdown, Nunjucks, Liquid
osv.) og tilpasse input- og outputmapper uden komplekse setups.

### Repository‑struktur

```
florelfiskeri-site/
├── content/        # Oversatte Markdown-filer per sprog
│   ├── da/
│   │   └── index.md
│   ├── en/
│   │   └── index.md
│   └── de/
│       └── index.md
├── content/_includes/
│   └── layout.njk  # Basistemplate anvendt af alle sider
├── assets/         # Billeder og styles
│   ├── styles.css
│   └── ...
├── .eleventy.js    # Eleventy konfiguration
├── package.json    # NPM scripts og afhængigheder
├── netlify.toml    # Konfiguration til Netlify (kan anvendes sammen med gh-pages)
├── .github/workflows/deploy.yml # Workflow til build/deploy
└── docs/           # Dokumentation, herunder denne fil
```

### Deployment

Projektet kan deployes på to måder:

1. **GitHub Pages.** GitHub Actions workflow (`.github/workflows/deploy.yml`)
   bygger projektet og publicerer `dist` mappen til en `gh-pages` branch. Dette
   giver en gratis hostingløsning og gør det let at forhåndsvise ændringer
   direkte via GitHub.
2. **Netlify.** Konfigureres via `netlify.toml` og kan bruges som alternativ
   hostingplatform. Netlify understøtter også forhåndsvisninger for pull
   requests og giver globale CDN, hvilket sikrer hurtige loadtider. På sigt kan
   du aktivere Netlify CMS som et headless CMS, hvis ikke-tekniske brugere skal
   redigere indhold via en grafisk brugerflade.

## Guidelines for AI‑bidrag

For at AI‑assistenter kan hjælpe effektivt, er her nogle retningslinjer:

1. **Følg repository‑strukturen.** Indhold tilføjes eller opdateres i
   `content/<sprog>/` mapperne. Skabeloner og layouts findes i
   `content/_includes/`. Assets (billeder, ikoner, CSS) placeres i
   `assets/`.
2. **Brug Markdown med front matter.** Hver indholdsside starter med YAML
   front matter (f.eks. `title`, `lang`, `description`). Dette gør det let at
   tilføje metadata til SEO og oversættelse.
3. **Skalering til flere sprog.** Når nyt indhold tilføjes, opret en kopi i
   hvert sprogmappe og oversæt. Angiv `lang` i front matter for korrekt
   `<html lang="...">` output.
4. **Meta‑data og SEO.** Tilføj beskrivende `title` og `description` i front
   matter. Disse bruges til `<title>` og `<meta name="description">` i
   outputtet.  For SEO anbefales unikke, klare titler og beskrivelser pr. side.
5. **Optimal ydeevne.** Undgå at inkludere store biblioteker eller ubrugte
   CSS/JS. Statiske sider indlæses hurtigst muligt, fordi serveren kun
   leverer HTML og assets【466348351120401†L205-L215】.  Billeder bør
   optimeres (brug gerne WebP) og placeres i `assets/` mappen.
6. **Versionskontrol.** Nye ændringer skal laves via pull requests.  Brug
   beskrivende commit‑meddelelser og link til issue‑numre. Denne fil er
   versionsstyret (v1.0). Ved større ændringer i arkitekturen eller
   retningslinjerne skal versionen opdateres (f.eks. `v1.1`) og en
   changelog tilføjes.
7. **Dokumentation.** Udbyg `docs/` mappen med yderligere guider (f.eks.
   oversættelsesguide, SEO‑checkliste, og udviklingsvejledning).  En klar
   dokumentation gør det nemt for AI og mennesker at forstå projektet.
8. **Automatiserede checks.** Overvej at tilføje flere GitHub Actions, der
   eksempelvis kører link‑checkers, accessibility tests, eller genererer
   Lighthouse‑rapporter på en tidsplan. Dette hjælper AI med at
   identificere performance‑flaskehalse og SEO‑problemer.

## Hvorfor denne konfiguration?

* **Performance:** Statisk genererede sider har lavere serverbelastning og
  hurtigere indlæsningstider. De kræver ikke databaser eller server‑side
  rendering, hvilket betyder færre forespørgsler og dermed hurtigere
  svartider【466348351120401†L205-L215】.
* **Simpel vedligeholdelse:** Indhold og layout adskilles. Tekster ligger i
  Markdown‑filer, mens skabeloner håndterer præsentationen. Dette gør det
  let for AI at opdatere tekster uden at ændre HTML‑strukturen.
* **Skalerbarhed til flere sprog:** Ved at strukturere indhold pr. sprog kan
  projektet nemt udvides til nye markeder. Eleventy understøtter flere
  skabelonsprog og indlæsning af globale data, hvilket forenkler
  internationalisering.
* **Integration med CI/CD:** GitHub Actions automatiserer build og deploy,
  så alle ændringer kører gennem en ensartet proces. Dette reducerer
  risikoen for menneskelige fejl og giver AI tydelige points of
  intervention (f.eks. automatisk PR‑review).

## Fremtidige forbedringer

Dette er version 1.0 af dokumentationen. Fremtidige versioner kan
inkludere:

1. **Skema markup (Schema.org)**: Tilføj JSON‑LD til templates for at
   forbedre synlighed i søgemaskiner og AI‑assistenter.
2. **Headless CMS integration:** Netlify CMS eller Sanity kan integreres for
   grafisk redigering. Dette kan kræve yderligere konfigurationer i
   `package.json` og `netlify.toml`.
3. **Testing og kvalitetssikring:** Tilføj automatiske tests for link
   validering, stavekontrol og tilgængelighed.

Ved eventuelle spørgsmål eller hvis AI opdager problemer, bør en issue
oprettes i GitHub‑repositoryet med præcis beskrivelse og forslag til
løsning.

---

*Denne dokumentation er udviklet i samarbejde mellem udvikleren og en
AI‑assistent.  Opdater versionen og datoen, når større ændringer foretages.*