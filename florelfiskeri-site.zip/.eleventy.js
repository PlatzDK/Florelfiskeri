/**
 * Eleventy configuration file
 *
 * Eleventy (11ty) is a simple static site generator that gives full control over
 * the output. By default it does not include any large JavaScript bundles,
 * resulting in lightweight, fast‑loading sites【593521916954360†L168-L174】.  We use
 * Eleventy here because it is praised for its simplicity, flexibility and
 * speed【880433695797556†L80-L105】.  The configuration below tells Eleventy where
 * to find the source files and where to write the generated HTML.
 */
module.exports = function (eleventyConfig) {
  // Passthrough copy for static assets such as images and icons
  eleventyConfig.addPassthroughCopy({ "assets": "assets" });

  return {
    dir: {
      input: "content",     // folder with Markdown/HTML content
      includes: "_includes", // reusable templates and partials
      data: "_data",        // global data files
      output: "dist"        // output folder for the built site
    },
    markdownTemplateEngine: "liquid",
    htmlTemplateEngine: "liquid",
    templateFormats: ["md", "njk", "html"]
  };
};