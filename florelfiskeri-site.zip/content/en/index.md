---
layout: layout.njk
title: "Welcome to Florel Fiskeri"
lang: "en"
description: "Cozy holiday home by the Karup River with room for 6 guests."
---

# Welcome to Florel Fiskeri

This static website is an example of how content can be organised into
Markdown files and translated into multiple languages.  The underlying
architecture uses Eleventy, which generates fast, static pages without heavy
runtime libraries【593521916954360†L168-L174】.  You can place additional
Markdown files in this folder to describe the summer house, its amenities,
pricing and practical information.
