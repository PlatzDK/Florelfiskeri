---
layout: layout.njk
title: "Velkommen til Florel Fiskeri"
lang: "da"
description: "Hyggeligt sommerhus ved Karup Å med plads til 6 personer."
---

# Velkommen til Florel Fiskeri

Dette statiske websted er et eksempel på, hvordan indhold kan organiseres i
Markdown‑filer og oversættes til forskellige sprog. Den underliggende
arkitektur er baseret på Eleventy, som genererer hurtige, statiske sider
uden tunge runtime‑biblioteker【593521916954360†L168-L174】.  Du kan placere flere
Markdown‑filer i denne mappe for at beskrive sommerhuset, faciliteter, priser
og praktisk information.
