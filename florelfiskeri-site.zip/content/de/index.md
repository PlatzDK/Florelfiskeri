---
layout: layout.njk
title: "Willkommen bei Florel Fiskeri"
lang: "de"
description: "Gemütliches Ferienhaus an der Karup Au mit Platz für 6 Personen."
---

# Willkommen bei Florel Fiskeri

Diese statische Website zeigt, wie Inhalte in Markdown‑Dateien organisiert
werden und in mehrere Sprachen übersetzt werden können.  Die zugrunde
liegende Architektur basiert auf Eleventy, das schnelle, statische Seiten
ohne umfangreiche Laufzeitbibliotheken erzeugt【593521916954360†L168-L174】.
Sie können weitere Markdown‑Dateien in diesem Ordner platzieren, um das
Sommerhaus, die Ausstattung, Preise und praktische Informationen zu
beschreiben.
